package org.gstreamer.elements;



import org.gstreamer.lowlevel.GstAPI.GstCallback;



import com.sun.jna.Pointer;



public class CairoOverlay extends BaseTransform {
	public static final String GST_NAME = "cairooverlay";

	public CairoOverlay(Initializer init) {
		super(init);

	}
	
	 public static interface DRAW {
	        /**
	  
	         */
	        public void draw(CairoOverlay overlay, Pointer ctx,/*guint64*/ long timestamp,/*guint64*/ long duration,Pointer user_data );
	    }
	   public static interface CAPS_CHANGED {
	        /**
	  (GstCairoOverlay *gstcairooverlay,
                                                       GstCaps         *arg1,
                                                       gpointer         user_data)
	         */
	        public void caps_changed(CairoOverlay overlay, org.gstreamer.Caps caps,Pointer user_data );
	    }
	   public void connect(final DRAW listener) {
	        connect(DRAW.class, listener, new GstCallback() {

	            public void callback(CairoOverlay overlay, Pointer ctx,/*guint64*/ long timestamp,/*guint64*/ long duration,Pointer user_data) {
	                listener.draw(overlay, ctx, timestamp, duration, user_data);
	            }
	        });

}
	   
	   public void disconnect(DRAW listener){
		   disconnect(DRAW.class, listener);
	   }

	
	 
	   public void connect(final CAPS_CHANGED listener) {
	        connect(CAPS_CHANGED.class, listener, new GstCallback() {

	            public void callback(CairoOverlay overlay, org.gstreamer.Caps caps,Pointer user_data ) {
	                listener.caps_changed(overlay,caps, user_data);
	            }
	        });

}
	   public void disconnect(CAPS_CHANGED listener){
		   disconnect(CAPS_CHANGED.class, listener);
	   }
}
